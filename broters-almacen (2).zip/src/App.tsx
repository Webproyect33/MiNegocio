import React, { useState, useEffect, useMemo } from 'react';
import {
  Warehouse,
  Home as HomeIcon,
  Layers,
  Users,
  ClipboardList,
  Calculator,
  RotateCcw,
  Plus,
  Pencil,
  Trash2,
  X,
  ChevronDown,
  ChevronUp,
  Search,
  Package,
  AlertCircle,
  Tag,
  DollarSign,
  TrendingUp,
  Clock,
  ArrowRight,
  KeyRound,
  Eye,
  EyeOff,
  UserPlus,
  Filter,
  FileText,
  Check,
  ShieldCheck,
  FileDown,
  FileUp,
  Download,
  CheckCircle2
} from 'lucide-react';
import { Product, Category, Salesperson, SaleReport, ActivityLog, ActionType } from './types.ts';

const STORAGE_KEY_PRODUCTS = 'broters_almacen_products_v1';
const STORAGE_KEY_CATEGORIES = 'broters_almacen_categories_v1';
const STORAGE_KEY_SALESPERSONS = 'broters_almacen_salespersons_v1';
const STORAGE_KEY_REPORTS = 'broters_almacen_reports_v1';
const STORAGE_KEY_LOGS = 'broters_almacen_logs_v1';

const DEFAULT_CATEGORIES: Category[] = [
  { id: 'cat-1', name: 'Bebidas', description: 'Refrescos, aguas y jugos', color: '#3b82f6', createdAt: new Date().toISOString() },
  { id: 'cat-2', name: 'Alimentos', description: 'Comestibles y enlatados', color: '#10b981', createdAt: new Date().toISOString() },
  { id: 'cat-3', name: 'Limpieza', description: 'Artículos de aseo e higiene', color: '#8b5cf6', createdAt: new Date().toISOString() },
  { id: 'cat-4', name: 'General', description: 'Productos varios', color: '#64748b', createdAt: new Date().toISOString() },
];

const DEFAULT_SALESPERSONS: Salesperson[] = [
  { id: 'vend-1', username: 'maria.lopez', name: 'María López', password: '1234', phone: '+1 555-0192', createdAt: new Date().toISOString() },
  { id: 'vend-2', username: 'ana.torres', name: 'Ana Torres', password: '4321', phone: '+1 555-0145', createdAt: new Date().toISOString() },
];

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [progress, setProgress] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<number>(0);

  // Estados persistentes en almacenamiento local del teléfono (100% offline)
  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CATEGORIES);
      return saved ? JSON.parse(saved) : DEFAULT_CATEGORIES;
    } catch {
      return DEFAULT_CATEGORIES;
    }
  });

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PRODUCTS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [salespersons, setSalespersons] = useState<Salesperson[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SALESPERSONS);
      return saved ? JSON.parse(saved) : DEFAULT_SALESPERSONS;
    } catch {
      return DEFAULT_SALESPERSONS;
    }
  });

  const [reports, setReports] = useState<SaleReport[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REPORTS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [logs, setLogs] = useState<ActivityLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_LOGS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Guardado automático local
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_CATEGORIES, JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_SALESPERSONS, JSON.stringify(salespersons));
  }, [salespersons]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_REPORTS, JSON.stringify(reports));
  }, [reports]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(logs));
  }, [logs]);

  // Splash screen de 3 segundos
  useEffect(() => {
    if (!showSplash) return;
    setProgress(0);
    const totalDuration = 3000;
    const intervalTime = 50;
    const increment = 100 / (totalDuration / intervalTime);

    const progressTimer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(progressTimer);
          return 100;
        }
        return next;
      });
    }, intervalTime);

    const splashTimeout = setTimeout(() => {
      setShowSplash(false);
    }, totalDuration);

    return () => {
      clearInterval(progressTimer);
      clearTimeout(splashTimeout);
    };
  }, [showSplash]);

  const addLog = (
    actionType: ActionType,
    productName: string,
    description: string,
    details: ActivityLog['details'],
    productId?: string
  ) => {
    const newLog: ActivityLog = {
      id: Date.now().toString() + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString(),
      actionType,
      productId,
      productName,
      description,
      details,
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // Modales Producto
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [stockModalProduct, setStockModalProduct] = useState<Product | null>(null);
  const [deletingProduct, setDeletingProduct] = useState<Product | null>(null);

  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formBuyPrice, setFormBuyPrice] = useState('');
  const [formSellPrice, setFormSellPrice] = useState('');
  const [formStock, setFormStock] = useState('');
  const [formError, setFormError] = useState('');

  const [stockToAdd, setStockToAdd] = useState('');
  const [stockNote, setStockNote] = useState('');
  const [stockError, setStockError] = useState('');

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedHomeCategory, setSelectedHomeCategory] = useState('Todas');

  // Modales Categoría
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deletingCategory, setDeletingCategory] = useState<Category | null>(null);
  const [catName, setCatName] = useState('');
  const [catDesc, setCatDesc] = useState('');
  const [catColor, setCatColor] = useState('#3b82f6');
  const [catError, setCatError] = useState('');

  // Modales Vendedora
  const [isSalespersonModalOpen, setIsSalespersonModalOpen] = useState(false);
  const [editingSalesperson, setEditingSalesperson] = useState<Salesperson | null>(null);
  const [resetPassSalesperson, setResetPassSalesperson] = useState<Salesperson | null>(null);
  const [deletingSalesperson, setDeletingSalesperson] = useState<Salesperson | null>(null);
  const [vendName, setVendName] = useState('');
  const [vendUsername, setVendUsername] = useState('');
  const [vendPassword, setVendPassword] = useState('');
  const [vendPhone, setVendPhone] = useState('');
  const [vendError, setVendError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [newResetPassword, setNewResetPassword] = useState('');

  // Modales Informes y Cuentas
  const [isNewReportModalOpen, setIsNewReportModalOpen] = useState(false);
  const [isCalculateModalOpen, setIsCalculateModalOpen] = useState(false);
  const [reportFilterSalesperson, setReportFilterSalesperson] = useState('Todas');
  const [reportFilterProduct, setReportFilterProduct] = useState('Todos');
  const [reportFilterDate, setReportFilterDate] = useState('');

  const [repSalespersonId, setRepSalespersonId] = useState('');
  const [repDate, setRepDate] = useState(new Date().toISOString().split('T')[0]);
  const [repItems, setRepItems] = useState<{ productId: string; quantity: number }[]>([]);
  const [repNotes, setRepNotes] = useState('');
  const [repError, setRepError] = useState('');

  const [calcSalesperson, setCalcSalesperson] = useState('all');
  const [calcPeriod, setCalcPeriod] = useState<'today' | '7days' | '30days' | 'this_month' | 'this_year' | 'all' | 'custom'>('all');
  const [calcCustomStart, setCalcCustomStart] = useState('');
  const [calcCustomEnd, setCalcCustomEnd] = useState('');

  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [logFilter, setLogFilter] = useState<'all' | ActionType>('all');
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [backupMessage, setBackupMessage] = useState<string | null>(null);

  // Exportar Copia de Seguridad JSON
  const handleExportBackup = () => {
    try {
      const backupData = {
        app: 'Broters_Almacen',
        version: '1.2.0',
        exportedAt: new Date().toISOString(),
        products,
        categories,
        salespersons,
        reports,
        logs,
      };
      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `copia_seguridad_almacen_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setBackupMessage('¡Copia de seguridad descargada con éxito!');
      setTimeout(() => setBackupMessage(null), 4000);
    } catch (err) {
      console.error('Error al exportar copia de seguridad:', err);
    }
  };

  // Restaurar Copia de Seguridad JSON
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const data = JSON.parse(text);

        let restoredItems = 0;
        if (data.products && Array.isArray(data.products)) {
          setProducts(data.products);
          restoredItems += data.products.length;
        }
        if (data.categories && Array.isArray(data.categories)) {
          setCategories(data.categories);
        }
        if (data.salespersons && Array.isArray(data.salespersons)) {
          setSalespersons(data.salespersons);
        }
        if (data.reports && Array.isArray(data.reports)) {
          setReports(data.reports);
        }
        if (data.logs && Array.isArray(data.logs)) {
          setLogs(data.logs);
        }

        setBackupMessage(`¡Copia restaurada! Se cargaron ${restoredItems} productos y todo el historial.`);
        setTimeout(() => setBackupMessage(null), 5000);
        setIsBackupModalOpen(false);
      } catch (err) {
        alert('El archivo seleccionado no es una copia de seguridad válida.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Funciones Productos
  const openCreateProductModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormCategory(categories.length > 0 ? categories[0].name : 'General');
    setFormBuyPrice('');
    setFormSellPrice('');
    setFormStock('');
    setFormError('');
    setIsAddModalOpen(true);
  };

  const openEditProductModal = (p: Product) => {
    setEditingProduct(p);
    setFormName(p.name);
    setFormCategory(p.category || (categories[0]?.name ?? 'General'));
    setFormBuyPrice(p.buyPrice.toString());
    setFormSellPrice(p.sellPrice.toString());
    setFormStock(p.stock.toString());
    setFormError('');
    setIsAddModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setFormError('El nombre del producto es obligatorio.');
      return;
    }
    const buyPrice = parseFloat(formBuyPrice) || 0;
    const sellPrice = parseFloat(formSellPrice) || 0;
    const stock = parseInt(formStock, 10) || 0;

    if (buyPrice < 0 || sellPrice < 0 || stock < 0) {
      setFormError('Los precios y el stock no pueden ser negativos.');
      return;
    }

    const category = formCategory || (categories[0]?.name ?? 'General');

    if (editingProduct) {
      const updatedProduct: Product = {
        ...editingProduct,
        name: formName.trim(),
        category,
        buyPrice,
        sellPrice,
        stock,
        updatedAt: new Date().toISOString(),
      };

      setProducts((prev) =>
        prev.map((item) => (item.id === editingProduct.id ? updatedProduct : item))
      );

      addLog(
        'edit',
        formName.trim(),
        `Se modificaron los datos del producto "${formName.trim()}".`,
        { previousData: editingProduct, newData: updatedProduct },
        editingProduct.id
      );
    } else {
      const newProduct: Product = {
        id: Date.now().toString(),
        name: formName.trim(),
        category,
        buyPrice,
        sellPrice,
        stock,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setProducts((prev) => [newProduct, ...prev]);

      addLog(
        'create',
        newProduct.name,
        `Se creó el producto "${newProduct.name}" en categoría ${category} con stock inicial de ${stock} u.`,
        { newStock: stock, newData: newProduct },
        newProduct.id
      );
    }

    setIsAddModalOpen(false);
  };

  const handleSaveStock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stockModalProduct) return;
    const amount = parseInt(stockToAdd, 10);
    if (isNaN(amount) || amount <= 0) {
      setStockError('Ingresa una cantidad mayor a 0 para añadir.');
      return;
    }

    const prevStock = stockModalProduct.stock;
    const newStock = prevStock + amount;

    setProducts((prev) =>
      prev.map((item) =>
        item.id === stockModalProduct.id
          ? { ...item, stock: newStock, updatedAt: new Date().toISOString() }
          : item
      )
    );

    addLog(
      'add_stock',
      stockModalProduct.name,
      `Se añadieron +${amount} unidades a "${stockModalProduct.name}". Stock: ${prevStock} → ${newStock}.`,
      { previousStock: prevStock, addedStock: amount, newStock, note: stockNote.trim() || undefined },
      stockModalProduct.id
    );

    setStockModalProduct(null);
  };

  const handleConfirmDeleteProduct = () => {
    if (!deletingProduct) return;
    setProducts((prev) => prev.filter((p) => p.id !== deletingProduct.id));
    addLog(
      'delete',
      deletingProduct.name,
      `Se eliminó el producto "${deletingProduct.name}" del almacén.`,
      { previousData: deletingProduct },
      deletingProduct.id
    );
    setDeletingProduct(null);
  };

  // Funciones Categorías
  const openCreateCategoryModal = () => {
    setEditingCategory(null);
    setCatName('');
    setCatDesc('');
    setCatColor('#3b82f6');
    setCatError('');
    setIsCategoryModalOpen(true);
  };

  const openEditCategoryModal = (cat: Category) => {
    setEditingCategory(cat);
    setCatName(cat.name);
    setCatDesc(cat.description || '');
    setCatColor(cat.color || '#3b82f6');
    setCatError('');
    setIsCategoryModalOpen(true);
  };

  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim()) {
      setCatError('El nombre de la categoría es obligatorio.');
      return;
    }

    const exists = categories.some(
      (c) => c.name.toLowerCase() === catName.trim().toLowerCase() && c.id !== editingCategory?.id
    );
    if (exists) {
      setCatError('Ya existe una categoría con ese nombre.');
      return;
    }

    if (editingCategory) {
      const oldName = editingCategory.name;
      const updatedCat: Category = {
        ...editingCategory,
        name: catName.trim(),
        description: catDesc.trim() || undefined,
        color: catColor,
      };

      setCategories((prev) => prev.map((c) => (c.id === editingCategory.id ? updatedCat : c)));

      if (oldName !== catName.trim()) {
        setProducts((prev) =>
          prev.map((p) => (p.category === oldName ? { ...p, category: catName.trim() } : p))
        );
      }

      addLog(
        'category_edit',
        catName.trim(),
        `Se editó la categoría "${oldName}" ${oldName !== catName.trim() ? `a "${catName.trim()}"` : ''}.`,
        { previousData: editingCategory, newData: updatedCat }
      );
    } else {
      const newCat: Category = {
        id: 'cat-' + Date.now().toString(),
        name: catName.trim(),
        description: catDesc.trim() || undefined,
        color: catColor,
        createdAt: new Date().toISOString(),
      };
      setCategories((prev) => [...prev, newCat]);
      addLog('category_create', newCat.name, `Se creó la nueva categoría "${newCat.name}".`, { newData: newCat });
    }

    setIsCategoryModalOpen(false);
  };

  const handleConfirmDeleteCategory = () => {
    if (!deletingCategory) return;
    const catNameToDelete = deletingCategory.name;
    setCategories((prev) => prev.filter((c) => c.id !== deletingCategory.id));
    setProducts((prev) =>
      prev.map((p) => (p.category === catNameToDelete ? { ...p, category: 'General' } : p))
    );
    addLog(
      'category_delete',
      catNameToDelete,
      `Se eliminó la categoría "${catNameToDelete}". Los productos asignados pasaron a General.`,
      { previousData: deletingCategory }
    );
    setDeletingCategory(null);
  };

  // Funciones Vendedoras
  const openCreateSalespersonModal = () => {
    setEditingSalesperson(null);
    setVendName('');
    setVendUsername('');
    setVendPassword('');
    setVendPhone('');
    setVendError('');
    setShowPassword(false);
    setIsSalespersonModalOpen(true);
  };

  const openEditSalespersonModal = (v: Salesperson) => {
    setEditingSalesperson(v);
    setVendName(v.name);
    setVendUsername(v.username);
    setVendPassword(v.password);
    setVendPhone(v.phone || '');
    setVendError('');
    setShowPassword(false);
    setIsSalespersonModalOpen(true);
  };

  const handleSaveSalesperson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vendName.trim() || !vendUsername.trim() || !vendPassword.trim()) {
      setVendError('Nombre, usuario y contraseña son campos requeridos.');
      return;
    }

    const usernameClean = vendUsername.trim().toLowerCase();
    const exists = salespersons.some(
      (s) => s.username.toLowerCase() === usernameClean && s.id !== editingSalesperson?.id
    );
    if (exists) {
      setVendError('El nombre de usuario ya está en uso.');
      return;
    }

    if (editingSalesperson) {
      const updatedVend: Salesperson = {
        ...editingSalesperson,
        name: vendName.trim(),
        username: usernameClean,
        password: vendPassword.trim(),
        phone: vendPhone.trim() || undefined,
        updatedAt: new Date().toISOString(),
      };

      setSalespersons((prev) =>
        prev.map((s) => (s.id === editingSalesperson.id ? updatedVend : s))
      );

      addLog(
        'salesperson_edit',
        updatedVend.name,
        `Se editaron los datos de la vendedora "${updatedVend.name}" (@${updatedVend.username}).`,
        { previousData: editingSalesperson, newData: updatedVend }
      );
    } else {
      const newVend: Salesperson = {
        id: 'vend-' + Date.now().toString(),
        name: vendName.trim(),
        username: usernameClean,
        password: vendPassword.trim(),
        phone: vendPhone.trim() || undefined,
        createdAt: new Date().toISOString(),
      };

      setSalespersons((prev) => [...prev, newVend]);
      addLog(
        'salesperson_create',
        newVend.name,
        `Se creó el acceso para la vendedora "${newVend.name}" (@${newVend.username}).`,
        { newData: newVend }
      );
    }

    setIsSalespersonModalOpen(false);
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetPassSalesperson || !newResetPassword.trim()) return;

    setSalespersons((prev) =>
      prev.map((s) =>
        s.id === resetPassSalesperson.id
          ? { ...s, password: newResetPassword.trim(), updatedAt: new Date().toISOString() }
          : s
      )
    );

    addLog(
      'salesperson_reset_pass',
      resetPassSalesperson.name,
      `Se restableció la contraseña de acceso para "${resetPassSalesperson.name}" (@${resetPassSalesperson.username}).`,
      { note: 'Contraseña actualizada' }
    );

    setResetPassSalesperson(null);
    setNewResetPassword('');
  };

  const handleConfirmDeleteSalesperson = () => {
    if (!deletingSalesperson) return;
    setSalespersons((prev) => prev.filter((s) => s.id !== deletingSalesperson.id));
    addLog(
      'salesperson_edit',
      deletingSalesperson.name,
      `Se eliminó el perfil de la vendedora "${deletingSalesperson.name}".`,
      { previousData: deletingSalesperson }
    );
    setDeletingSalesperson(null);
  };

  // Funciones Informes
  const openNewReportModal = () => {
    setRepSalespersonId(salespersons[0]?.id || '');
    setRepDate(new Date().toISOString().split('T')[0]);
    setRepItems(products.length > 0 ? [{ productId: products[0].id, quantity: 1 }] : []);
    setRepNotes('');
    setRepError('');
    setIsNewReportModalOpen(true);
  };

  const handleAddReportItemRow = () => {
    if (products.length === 0) return;
    setRepItems((prev) => [...prev, { productId: products[0].id, quantity: 1 }]);
  };

  const handleRemoveReportItemRow = (index: number) => {
    setRepItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSaveReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!repSalespersonId) {
      setRepError('Debes seleccionar la vendedora que envía el informe.');
      return;
    }
    if (repItems.length === 0) {
      setRepError('Debes agregar al menos un producto vendido.');
      return;
    }

    const salesperson = salespersons.find((s) => s.id === repSalespersonId);
    if (!salesperson) {
      setRepError('Vendedora no válida.');
      return;
    }

    const processedItems: SaleReport['items'] = [];
    let totalAmount = 0;
    let totalCost = 0;

    for (const item of repItems) {
      const prod = products.find((p) => p.id === item.productId);
      if (!prod) continue;
      const qty = Math.max(1, item.quantity || 1);
      const subtotal = prod.sellPrice * qty;
      const costSubtotal = prod.buyPrice * qty;

      totalAmount += subtotal;
      totalCost += costSubtotal;

      processedItems.push({
        productId: prod.id,
        productName: prod.name,
        quantity: qty,
        buyPrice: prod.buyPrice,
        sellPrice: prod.sellPrice,
        subtotal,
      });
    }

    if (processedItems.length === 0) {
      setRepError('No se pudo procesar ningún producto del informe.');
      return;
    }

    const totalProfit = totalAmount - totalCost;

    const newReport: SaleReport = {
      id: 'rep-' + Date.now().toString(),
      salespersonId: salesperson.id,
      salespersonName: salesperson.name,
      items: processedItems,
      totalAmount,
      totalCost,
      totalProfit,
      date: repDate || new Date().toISOString().split('T')[0],
      timestamp: new Date().toISOString(),
      notes: repNotes.trim() || undefined,
    };

    setReports((prev) => [newReport, ...prev]);

    setProducts((prev) =>
      prev.map((p) => {
        const itemSold = processedItems.find((it) => it.productId === p.id);
        if (itemSold) {
          return {
            ...p,
            stock: Math.max(0, p.stock - itemSold.quantity),
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      })
    );

    addLog(
      'report_create',
      salesperson.name,
      `Informe recibido de ${salesperson.name}: $${totalAmount.toFixed(2)} en ventas (${processedItems.reduce((acc, i) => acc + i.quantity, 0)} productos).`,
      { newData: newReport }
    );

    setIsNewReportModalOpen(false);
  };

  // Filtros
  const filteredHomeProducts = useMemo(() => {
    return products.filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCat =
        selectedHomeCategory === 'Todas' || p.category === selectedHomeCategory;
      return matchSearch && matchCat;
    });
  }, [products, searchTerm, selectedHomeCategory]);

  const filteredReports = useMemo(() => {
    return reports.filter((r) => {
      const matchSalesperson =
        reportFilterSalesperson === 'Todas' || r.salespersonId === reportFilterSalesperson;
      const matchDate = !reportFilterDate || r.date === reportFilterDate;
      const matchProduct =
        reportFilterProduct === 'Todos' ||
        r.items.some((it) => it.productId === reportFilterProduct);
      return matchSalesperson && matchDate && matchProduct;
    });
  }, [reports, reportFilterSalesperson, reportFilterDate, reportFilterProduct]);

  // Motor: Sacar las cuentas
  const calculatedAccounts = useMemo(() => {
    let matchingReports = reports;
    if (calcSalesperson !== 'all') {
      matchingReports = matchingReports.filter((r) => r.salespersonId === calcSalesperson);
    }

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    matchingReports = matchingReports.filter((r) => {
      const repDateObj = new Date(r.date + 'T00:00:00');
      if (calcPeriod === 'today') {
        return r.date === todayStr;
      } else if (calcPeriod === '7days') {
        const diffDays = (now.getTime() - repDateObj.getTime()) / (1000 * 3600 * 24);
        return diffDays >= 0 && diffDays <= 7;
      } else if (calcPeriod === '30days') {
        const diffDays = (now.getTime() - repDateObj.getTime()) / (1000 * 3600 * 24);
        return diffDays >= 0 && diffDays <= 30;
      } else if (calcPeriod === 'this_month') {
        return (
          repDateObj.getFullYear() === now.getFullYear() &&
          repDateObj.getMonth() === now.getMonth()
        );
      } else if (calcPeriod === 'this_year') {
        return repDateObj.getFullYear() === now.getFullYear();
      } else if (calcPeriod === 'custom') {
        if (calcCustomStart && r.date < calcCustomStart) return false;
        if (calcCustomEnd && r.date > calcCustomEnd) return false;
        return true;
      }
      return true;
    });

    const productStatsMap = new Map<
      string,
      {
        productId: string;
        productName: string;
        quantitySold: number;
        buyPrice: number;
        sellPrice: number;
        totalCost: number;
        totalSold: number;
        profit: number;
      }
    >();

    let totalProductsQty = 0;
    let totalBuyCost = 0;
    let totalSoldAmount = 0;

    matchingReports.forEach((rep) => {
      rep.items.forEach((item) => {
        totalProductsQty += item.quantity;
        const cost = item.buyPrice * item.quantity;
        const revenue = item.sellPrice * item.quantity;
        totalBuyCost += cost;
        totalSoldAmount += revenue;

        const current = productStatsMap.get(item.productId) || {
          productId: item.productId,
          productName: item.productName,
          quantitySold: 0,
          buyPrice: item.buyPrice,
          sellPrice: item.sellPrice,
          totalCost: 0,
          totalSold: 0,
          profit: 0,
        };

        current.quantitySold += item.quantity;
        current.totalCost += cost;
        current.totalSold += revenue;
        current.profit = current.totalSold - current.totalCost;

        productStatsMap.set(item.productId, current);
      });
    });

    const netProfit = totalSoldAmount - totalBuyCost;
    const profitMargin = totalSoldAmount > 0 ? (netProfit / totalSoldAmount) * 100 : 0;
    const productsBreakdown = Array.from(productStatsMap.values()).sort(
      (a, b) => b.quantitySold - a.quantitySold
    );

    return {
      reportsCount: matchingReports.length,
      totalProductsQty,
      totalBuyCost,
      totalSoldAmount,
      netProfit,
      profitMargin,
      productsBreakdown,
    };
  }, [reports, calcSalesperson, calcPeriod, calcCustomStart, calcCustomEnd]);

  // 5 Botones del Menú Inferior
  const navButtons = [
    { id: 0, label: 'Inicio', icon: HomeIcon },
    { id: 1, label: 'Categorías', icon: Layers },
    { id: 2, label: 'Vendedoras', icon: Users },
    { id: 3, label: 'Registros', icon: ClipboardList },
    { id: 4, label: 'Cuentas', icon: Calculator },
  ];

  if (showSplash) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-950 flex flex-col items-center justify-center p-6 text-white select-none">
        <div className="w-full max-w-sm flex flex-col items-center text-center">
          <div className="relative mb-8">
            <div className="w-28 h-28 rounded-3xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center shadow-2xl shadow-blue-500/10 backdrop-blur-md animate-pulse">
              <Warehouse className="w-16 h-16 text-blue-400 stroke-[1.75]" />
            </div>
          </div>

          <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
            Broters_Almacen
          </h1>
          <p className="text-sm font-medium text-slate-400 mb-8">
            Cargando sistema de gestión...
          </p>

          <div className="w-full bg-slate-700/60 rounded-full h-3 overflow-hidden p-0.5 border border-slate-600/40 shadow-inner">
            <div
              className="bg-gradient-to-r from-blue-500 to-cyan-400 h-full rounded-full transition-all duration-75 ease-linear"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>

          <div className="mt-3 flex justify-between w-full text-xs font-mono text-slate-400">
            <span>Iniciando...</span>
            <span>{Math.round(Math.min(progress, 100))}%</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800 antialiased select-none">
      <header className="sticky top-0 z-20 bg-white border-b border-slate-200 px-4 py-3 shadow-xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Warehouse className="w-5 h-5 stroke-[2]" />
            </div>
            <div>
              <h1 className="font-bold text-base text-slate-900 leading-tight">
                Broters_Almacen
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                {navButtons[activeTab].label}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsBackupModalOpen(true)}
              className="p-1.5 text-slate-600 hover:text-emerald-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Copia de Seguridad (Respaldar o Restaurar)"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
            </button>

            <button
              onClick={() => setShowSplash(true)}
              className="p-1.5 text-slate-500 hover:text-blue-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Ver Splash Screen"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-md w-full mx-auto p-4 pb-28">
        {/* Banner de Copia de Seguridad */}
        {backupMessage && (
          <div className="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-3 flex items-center gap-2 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{backupMessage}</span>
          </div>
        )}
        {/* 0. INICIO */}
        {activeTab === 0 && (
          <div>
            {products.length > 0 && (
              <div className="mb-4 space-y-2">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Buscar producto o categoría..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 shadow-xs"
                  />
                  {searchTerm && (
                    <button
                      onClick={() => setSearchTerm('')}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                  {['Todas', ...categories.map((c) => c.name)].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedHomeCategory(cat)}
                      className={`px-3 py-1 rounded-full whitespace-nowrap font-medium transition-colors ${
                        selectedHomeCategory === cat
                          ? 'bg-blue-600 text-white'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {products.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center shadow-xs flex flex-col items-center justify-center my-6">
                <div className="w-16 h-16 rounded-3xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 mb-4 shadow-inner">
                  <Package className="w-8 h-8 stroke-[1.75]" />
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-1">
                  No hay productos en el almacén
                </h3>
                <p className="text-xs text-slate-500 max-w-xs mb-6 leading-relaxed">
                  Presiona el botón flotante <strong>+</strong> en la esquina inferior derecha para agregar tu primer producto.
                </p>
                <button
                  onClick={openCreateProductModal}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-xs transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  <span>Agregar Producto</span>
                </button>
              </div>
            ) : filteredHomeProducts.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center shadow-xs">
                <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">Sin resultados</p>
                <p className="text-xs text-slate-500 mt-1">No se encontraron productos para los filtros.</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-500 font-medium px-1">
                  <span>Productos ({filteredHomeProducts.length})</span>
                  <span>Stock total: {filteredHomeProducts.reduce((acc, p) => acc + p.stock, 0)} u.</span>
                </div>

                {filteredHomeProducts.map((p) => {
                  const profit = p.sellPrice - p.buyPrice;
                  const catObj = categories.find((c) => c.name === p.category);
                  return (
                    <div
                      key={p.id}
                      className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:border-slate-300 transition-all"
                    >
                      <div className="flex items-start justify-between gap-2 mb-2.5">
                        <div className="flex-1">
                          <span
                            className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md"
                            style={{
                              backgroundColor: catObj?.color ? `${catObj.color}15` : '#f1f5f9',
                              color: catObj?.color || '#475569',
                            }}
                          >
                            {p.category || 'General'}
                          </span>
                          <h4 className="text-sm font-bold text-slate-900 mt-1 leading-snug">
                            {p.name}
                          </h4>
                        </div>

                        <div
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold text-center shrink-0 border ${
                            p.stock <= 0
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : p.stock <= 5
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}
                        >
                          <span className="block text-[10px] uppercase font-medium opacity-80">Stock</span>
                          <span>{p.stock} u.</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 bg-slate-50/80 rounded-xl p-2.5 border border-slate-100 text-xs mb-3">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-medium">Precio Compra</span>
                          <span className="font-semibold text-slate-700">${p.buyPrice.toFixed(2)}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-medium">Precio Venta</span>
                          <span className="font-semibold text-blue-600">${p.sellPrice.toFixed(2)}</span>
                          {profit > 0 && (
                            <span className="text-[9px] text-emerald-600 block font-medium">
                              +${profit.toFixed(2)} margen
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                        <button
                          onClick={() => {
                            setStockModalProduct(p);
                            setStockToAdd('');
                            setStockNote('');
                            setStockError('');
                          }}
                          className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold rounded-lg transition-colors active:scale-95 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                          <span>+ Stock</span>
                        </button>

                        <button
                          onClick={() => openEditProductModal(p)}
                          className="flex items-center justify-center gap-1 py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors active:scale-95 cursor-pointer"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                          <span>Editar</span>
                        </button>

                        <button
                          onClick={() => setDeletingProduct(p)}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition-colors active:scale-95 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* 1. CATEGORÍAS */}
        {activeTab === 1 && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-blue-600" />
                  <span>Gestión de Categorías</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Organiza y clasifica los productos de tu almacén.
                </p>
              </div>
              <button
                onClick={openCreateCategoryModal}
                className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white px-3 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Nueva</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {categories.map((cat) => {
                const prodCount = products.filter((p) => p.category === cat.name).length;
                const stockInCat = products
                  .filter((p) => p.category === cat.name)
                  .reduce((acc, p) => acc + p.stock, 0);

                return (
                  <div
                    key={cat.id}
                    className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm shadow-xs"
                        style={{ backgroundColor: cat.color || '#3b82f6' }}
                      >
                        {cat.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900 leading-tight">
                          {cat.name}
                        </h4>
                        {cat.description && (
                          <p className="text-xs text-slate-500 mt-0.5">{cat.description}</p>
                        )}
                        <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                          <span>{prodCount} productos</span>
                          <span>•</span>
                          <span>{stockInCat} u. en stock</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => openEditCategoryModal(cat)}
                        className="p-1.5 text-slate-600 hover:text-blue-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                        title="Editar categoría"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeletingCategory(cat)}
                        className="p-1.5 text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors cursor-pointer"
                        title="Eliminar categoría"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. VENDEDORAS */}
        {activeTab === 2 && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <span>Accesos de Vendedoras</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Usuarios, contraseñas y restablecimiento de claves.
                </p>
              </div>
              <button
                onClick={openCreateSalespersonModal}
                className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white px-3 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-all cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>Nueva</span>
              </button>
            </div>

            <div className="space-y-3">
              {salespersons.map((s) => {
                const totalReportsByHer = reports.filter((r) => r.salespersonId === s.id).length;
                const totalSalesByHer = reports
                  .filter((r) => r.salespersonId === s.id)
                  .reduce((acc, r) => acc + r.totalAmount, 0);

                return (
                  <div
                    key={s.id}
                    className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:border-slate-300 transition-all"
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-sm">
                          {s.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-slate-900 leading-tight">
                            {s.name}
                          </h4>
                          <p className="text-xs text-blue-600 font-mono mt-0.5">
                            @{s.username}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openEditSalespersonModal(s)}
                          className="p-1.5 text-slate-600 hover:text-blue-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeletingSalesperson(s)}
                          className="p-1.5 text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs mb-3">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">Contraseña Actual</span>
                        <span className="font-mono font-semibold text-slate-800">{s.password}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">Ventas Reportadas</span>
                        <span className="font-semibold text-emerald-600">
                          ${totalSalesByHer.toFixed(2)} ({totalReportsByHer} inf.)
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setResetPassSalesperson(s);
                        setNewResetPassword('');
                      }}
                      className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold rounded-lg transition-colors active:scale-95 cursor-pointer"
                    >
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>Restablecer Contraseña</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 3. REGISTROS */}
        {activeTab === 3 && (
          <div className="space-y-3">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <ClipboardList className="w-5 h-5 text-blue-600" />
                  <span>Registro de Notificaciones</span>
                </h2>
                <span className="text-xs font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
                  {logs.length}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Auditoría de todos los cambios realizados en el sistema.
              </p>

              <div className="flex gap-1 overflow-x-auto pt-3 text-[11px] scrollbar-none">
                {[
                  { id: 'all', label: 'Todos' },
                  { id: 'create', label: 'Productos' },
                  { id: 'add_stock', label: '+ Stock' },
                  { id: 'edit', label: 'Ediciones' },
                  { id: 'delete', label: 'Bajas' },
                  { id: 'category_create', label: 'Categorías' },
                  { id: 'salesperson_create', label: 'Vendedoras' },
                  { id: 'report_create', label: 'Informes' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setLogFilter(f.id as any)}
                    className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors cursor-pointer ${
                      logFilter === f.id ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2.5">
              {logs
                .filter((l) => logFilter === 'all' || l.actionType === logFilter)
                .map((log) => {
                  const isExpanded = expandedLogId === log.id;
                  const date = new Date(log.timestamp);
                  const formattedDate = date.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
                  const formattedTime = date.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });

                  return (
                    <div key={log.id} className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-xs">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                              {log.actionType}
                            </span>
                            <span className="text-[11px] text-slate-400 font-mono">{formattedTime}</span>
                          </div>
                          <h4 className="text-xs font-bold text-slate-900">{log.productName}</h4>
                          <p className="text-xs text-slate-600 mt-1">{log.description}</p>
                        </div>
                      </div>

                      <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                        <span className="text-[11px] text-slate-400">{formattedDate}</span>
                        <button
                          onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                          className="flex items-center gap-1 text-blue-600 hover:text-blue-800 font-semibold text-xs cursor-pointer"
                        >
                          <span>{isExpanded ? 'Ocultar' : 'Ver todos los detalles'}</span>
                          {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </button>
                      </div>

                      {isExpanded && (
                        <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
                          <div className="font-semibold text-slate-800 text-[11px] uppercase tracking-wider flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-blue-600" />
                            <span>Detalle Completo</span>
                          </div>

                          {log.details.note && (
                            <p className="text-[11px] text-slate-600 italic bg-amber-50 p-2 rounded-lg border border-amber-200">
                              Nota: {log.details.note}
                            </p>
                          )}

                          <div className="text-[10px] text-slate-400 font-mono text-right">
                            ID: {log.id}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* 4. INFORMES Y CUENTAS */}
        {activeTab === 4 && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-blue-600" />
                  <span>Informes y Cuentas</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Reportes de ventas recibidos de las vendedoras.
                </p>
              </div>
              <button
                onClick={openNewReportModal}
                className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white px-3 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Nuevo Informe</span>
              </button>
            </div>

            {/* Filtros */}
            <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-xs space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                <Filter className="w-3.5 h-3.5 text-blue-600" />
                <span>Filtrar Informes</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1 font-medium">Por Vendedora</label>
                  <select
                    value={reportFilterSalesperson}
                    onChange={(e) => setReportFilterSalesperson(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-xs text-slate-700"
                  >
                    <option value="Todas">Todas las vendedoras</option>
                    {salespersons.map((s) => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-1 font-medium">Por Producto</label>
                  <select
                    value={reportFilterProduct}
                    onChange={(e) => setReportFilterProduct(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-xs text-slate-700"
                  >
                    <option value="Todos">Todos los productos</option>
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-1 font-medium">Por Fecha</label>
                  <input
                    type="date"
                    value={reportFilterDate}
                    onChange={(e) => setReportFilterDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1 text-xs text-slate-700"
                  />
                </div>
              </div>

              {(reportFilterSalesperson !== 'Todas' || reportFilterProduct !== 'Todos' || reportFilterDate) && (
                <button
                  onClick={() => {
                    setReportFilterSalesperson('Todas');
                    setReportFilterProduct('Todos');
                    setReportFilterDate('');
                  }}
                  className="text-[11px] text-blue-600 font-medium flex items-center gap-1 cursor-pointer pt-1"
                >
                  <X className="w-3 h-3" />
                  <span>Limpiar filtros</span>
                </button>
              )}
            </div>

            {/* Listado de Informes */}
            {filteredReports.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 shadow-xs">
                <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">No hay informes</p>
                <p className="text-xs text-slate-400 mt-1 mb-4">
                  Registra los informes de venta recibidos de tus vendedoras.
                </p>
                <button
                  onClick={openNewReportModal}
                  className="bg-blue-600 text-white text-xs font-semibold px-4 py-2 rounded-xl cursor-pointer"
                >
                  Registrar Informe
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredReports.map((rep) => {
                  const repDateObj = new Date(rep.timestamp);
                  const formattedTime = repDateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

                  return (
                    <div
                      key={rep.id}
                      className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:border-slate-300 transition-all"
                    >
                      <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-slate-100">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
                            Vendedora
                          </span>
                          <h4 className="text-sm font-bold text-slate-900 mt-0.5">{rep.salespersonName}</h4>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-bold text-slate-700 block">{rep.date}</span>
                          <span className="text-[11px] text-slate-400 font-mono">{formattedTime}</span>
                        </div>
                      </div>

                      <div className="py-2.5 space-y-1.5">
                        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                          Productos vendidos:
                        </span>
                        {rep.items.map((item, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between text-xs py-1 px-2 bg-slate-50 rounded-lg"
                          >
                            <div className="flex-1">
                              <span className="font-semibold text-slate-800">{item.productName}</span>
                              <span className="text-slate-400 text-[11px] ml-1.5">
                                ({item.quantity} u. × ${item.sellPrice.toFixed(2)})
                              </span>
                            </div>
                            <span className="font-bold text-slate-800">${item.subtotal.toFixed(2)}</span>
                          </div>
                        ))}
                      </div>

                      <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                        <div className="text-slate-500 text-[11px]">Coste: ${rep.totalCost.toFixed(2)}</div>
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block font-medium">Total Informe</span>
                          <span className="text-sm font-bold text-blue-600">${rep.totalAmount.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Botón flotante Inicio (+) */}
      {activeTab === 0 && (
        <button
          onClick={openCreateProductModal}
          className="fixed right-5 bottom-20 z-30 w-14 h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white shadow-xl shadow-blue-600/30 flex items-center justify-center active:scale-95 transition-all cursor-pointer"
          title="Agregar nuevo producto"
        >
          <Plus className="w-7 h-7 stroke-[2.5]" />
        </button>
      )}

      {/* Botón flotante Cuentas (Sacar las Cuentas) */}
      {activeTab === 4 && (
        <button
          onClick={() => setIsCalculateModalOpen(true)}
          className="fixed right-5 bottom-20 z-30 px-4 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-xl shadow-emerald-600/30 flex items-center gap-2 font-bold text-xs active:scale-95 transition-all cursor-pointer"
          title="Sacar las cuentas de ventas y ganancias"
        >
          <Calculator className="w-5 h-5 stroke-[2.2]" />
          <span>Sacar las Cuentas</span>
        </button>
      )}

      {/* Barra de 5 botones inferior */}
      <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-slate-200 shadow-lg z-40">
        <div className="max-w-md mx-auto grid grid-cols-5 h-16 px-1">
          {navButtons.map((btn) => {
            const Icon = btn.icon;
            const isActive = activeTab === btn.id;
            return (
              <button
                key={btn.id}
                onClick={() => setActiveTab(btn.id)}
                type="button"
                className={`flex flex-col items-center justify-center py-1 transition-all duration-150 cursor-pointer ${
                  isActive ? 'text-blue-600 font-semibold' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <div className={`p-1 rounded-xl transition-colors ${isActive ? 'bg-blue-50' : 'bg-transparent'}`}>
                  <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.2]' : 'stroke-[1.75]'}`} />
                </div>
                <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-full px-1">
                  {btn.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Modal Sacar las Cuentas */}
      {isCalculateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-md mx-auto rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Calculator className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm leading-tight">Sacar las Cuentas</h3>
                  <p className="text-[11px] text-slate-400">Balance de ventas, costes y ganancias</p>
                </div>
              </div>
              <button
                onClick={() => setIsCalculateModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <label className="text-[11px] font-bold text-slate-700 block mb-1.5 uppercase">
                  1. Selección de Vendedora(s):
                </label>
                <select
                  value={calcSalesperson}
                  onChange={(e) => setCalcSalesperson(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs font-semibold text-slate-800"
                >
                  <option value="all">Todas las vendedoras ({salespersons.length})</option>
                  {salespersons.map((s) => (
                    <option key={s.id} value={s.id}>{s.name} (@{s.username})</option>
                  ))}
                </select>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <label className="text-[11px] font-bold text-slate-700 block uppercase">
                  2. Período / Cantidad de Días:
                </label>
                <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                  {[
                    { id: 'today', label: 'Hoy' },
                    { id: '7days', label: '7 Días' },
                    { id: '30days', label: '30 Días' },
                    { id: 'this_month', label: 'Este Mes' },
                    { id: 'this_year', label: 'Este Año' },
                    { id: 'all', label: 'Todo' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setCalcPeriod(p.id as any)}
                      className={`py-1.5 px-2 rounded-lg font-medium border text-center transition-colors cursor-pointer ${
                        calcPeriod === p.id
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                {calcPeriod === 'custom' && (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">Desde:</span>
                      <input
                        type="date"
                        value={calcCustomStart}
                        onChange={(e) => setCalcCustomStart(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs text-slate-700"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">Hasta:</span>
                      <input
                        type="date"
                        value={calcCustomEnd}
                        onChange={(e) => setCalcCustomEnd(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs text-slate-700"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 block uppercase font-medium">Productos Vendidos</span>
                  <p className="text-xl font-bold text-slate-900 mt-0.5">
                    {calculatedAccounts.totalProductsQty} <span className="text-xs font-normal text-slate-500">u.</span>
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 block uppercase font-medium">Informes Incluidos</span>
                  <p className="text-xl font-bold text-slate-900 mt-0.5">
                    {calculatedAccounts.reportsCount}
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 block uppercase font-medium">Coste Compra Total</span>
                  <p className="text-base font-bold text-slate-800 mt-0.5">
                    ${calculatedAccounts.totalBuyCost.toFixed(2)}
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 block uppercase font-medium">Monto Total Vendido</span>
                  <p className="text-base font-bold text-blue-600 mt-0.5">
                    ${calculatedAccounts.totalSoldAmount.toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-2xl p-4 shadow-sm">
                <span className="text-xs font-semibold uppercase tracking-wider text-emerald-100 flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  <span>Ganancia Neta Obtenida:</span>
                </span>
                <div className="flex items-baseline justify-between mt-1">
                  <h2 className="text-2xl font-extrabold tracking-tight">
                    ${calculatedAccounts.netProfit.toFixed(2)}
                  </h2>
                  <span className="text-xs font-bold bg-white/20 px-2.5 py-1 rounded-full">
                    {calculatedAccounts.profitMargin.toFixed(1)}% Margen
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Desglose por Producto Vendido ({calculatedAccounts.productsBreakdown.length})
                </h4>

                {calculatedAccounts.productsBreakdown.length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-2 text-center">
                    No hubo ventas en el período seleccionado.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {calculatedAccounts.productsBreakdown.map((prod) => (
                      <div
                        key={prod.productId}
                        className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1.5"
                      >
                        <div className="flex items-center justify-between font-bold text-slate-900">
                          <span>{prod.productName}</span>
                          <span className="text-blue-600">{prod.quantitySold} vendidas</span>
                        </div>

                        <div className="grid grid-cols-3 gap-1 text-[11px] text-slate-600 pt-1 border-t border-slate-200">
                          <div>
                            <span className="text-[9px] text-slate-400 block font-medium">P. Compra</span>
                            <span>${prod.buyPrice.toFixed(2)}</span>
                          </div>
                          <div>
                            <span className="text-[9px] text-slate-400 block font-medium">P. Venta</span>
                            <span>${prod.sellPrice.toFixed(2)}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-[9px] text-emerald-600 block font-medium">Ganancia</span>
                            <span className="font-bold text-emerald-700">+${prod.profit.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="p-3 border-t border-slate-200 bg-slate-50">
              <button
                onClick={() => setIsCalculateModalOpen(false)}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs cursor-pointer"
              >
                Cerrar Cuentas
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modales de Formulario */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl p-5 text-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900">
                {editingProduct ? 'Editar Producto' : 'Nuevo Producto'}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-3">
              {formError && (
                <div className="p-2 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-[11px]">
                  {formError}
                </div>
              )}

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nombre *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Harina de Trigo 1kg"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Categoría *</label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">P. Compra ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={formBuyPrice}
                    onChange={(e) => setFormBuyPrice(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">P. Venta ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={formSellPrice}
                    onChange={(e) => setFormSellPrice(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Stock Inicial</label>
                <input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={formStock}
                  onChange={(e) => setFormStock(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold cursor-pointer"
                >
                  {editingProduct ? 'Guardar' : 'Crear'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Añadir Stock */}
      {stockModalProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl p-5 text-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Agregar Stock</h3>
            <p className="text-xs text-slate-500 mb-3">
              {stockModalProduct.name} (Stock: {stockModalProduct.stock} u.)
            </p>
            <form onSubmit={handleSaveStock} className="space-y-3">
              {stockError && <div className="p-2 bg-rose-50 text-rose-700 rounded-lg text-[11px]">{stockError}</div>}
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Cantidad a añadir *</label>
                <input
                  type="number"
                  min="1"
                  autoFocus
                  required
                  placeholder="Ej: 10"
                  value={stockToAdd}
                  onChange={(e) => setStockToAdd(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setStockModalProduct(null)}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold cursor-pointer"
                >
                  Confirmar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Eliminar Producto */}
      {deletingProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl p-5 text-xs text-center">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">¿Eliminar "{deletingProduct.name}"?</h3>
            <div className="flex gap-2 mt-4">
              <button onClick={() => setDeletingProduct(null)} className="flex-1 py-2 bg-slate-100 rounded-xl font-medium cursor-pointer">Cancelar</button>
              <button onClick={handleConfirmDeleteProduct} className="flex-1 py-2 bg-rose-600 text-white rounded-xl font-semibold cursor-pointer">Eliminar</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Categoría */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl p-5 text-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3">{editingCategory ? 'Editar Categoría' : 'Nueva Categoría'}</h3>
            <form onSubmit={handleSaveCategory} className="space-y-3">
              {catError && <div className="p-2 bg-rose-50 text-rose-700 rounded-lg text-[11px]">{catError}</div>}
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nombre *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Lácteos"
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setIsCategoryModalOpen(false)} className="px-3 py-2 bg-slate-100 rounded-xl cursor-pointer">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-xl font-semibold cursor-pointer">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Eliminar Categoría */}
      {deletingCategory && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl p-5 text-xs text-center">
            <h3 className="text-sm font-bold text-slate-900 mb-2">¿Eliminar categoría "{deletingCategory.name}"?</h3>
            <p className="text-xs text-slate-500 mb-4">Los productos asociados pasarán a General.</p>
            <div className="flex gap-2">
              <button onClick={() => setDeletingCategory(null)} className="flex-1 py-2 bg-slate-100 rounded-xl cursor-pointer">Cancelar</button>
              <button onClick={handleConfirmDeleteCategory} className="flex-1 py-2 bg-rose-600 text-white rounded-xl font-semibold cursor-pointer">Eliminar</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Vendedora */}
      {isSalespersonModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl p-5 text-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3">{editingSalesperson ? 'Editar Vendedora' : 'Nueva Vendedora'}</h3>
            <form onSubmit={handleSaveSalesperson} className="space-y-3">
              {vendError && <div className="p-2 bg-rose-50 text-rose-700 rounded-lg text-[11px]">{vendError}</div>}
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nombre Completo *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Carmen Gómez"
                  value={vendName}
                  onChange={(e) => setVendName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nombre de Usuario *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: carmen.gomez"
                  value={vendUsername}
                  onChange={(e) => setVendUsername(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Contraseña *</label>
                <input
                  type="text"
                  required
                  placeholder="Contraseña de acceso"
                  value={vendPassword}
                  onChange={(e) => setVendPassword(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setIsSalespersonModalOpen(false)} className="px-3 py-2 bg-slate-100 rounded-xl cursor-pointer">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-xl font-semibold cursor-pointer">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Restablecer Contraseña */}
      {resetPassSalesperson && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl p-5 text-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Restablecer Contraseña</h3>
            <p className="text-xs text-slate-500 mb-3">{resetPassSalesperson.name} (@{resetPassSalesperson.username})</p>
            <form onSubmit={handleResetPassword} className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nueva Contraseña *</label>
                <input
                  type="text"
                  required
                  autoFocus
                  placeholder="Ingresa la nueva contraseña"
                  value={newResetPassword}
                  onChange={(e) => setNewResetPassword(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setResetPassSalesperson(null)} className="px-3 py-2 bg-slate-100 rounded-xl cursor-pointer">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-xl font-semibold cursor-pointer">Restablecer</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Eliminar Vendedora */}
      {deletingSalesperson && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl p-5 text-xs text-center">
            <h3 className="text-sm font-bold text-slate-900 mb-2">¿Eliminar acceso a {deletingSalesperson.name}?</h3>
            <p className="text-xs text-slate-500 mb-4">Los informes de venta previos se conservarán.</p>
            <div className="flex gap-2">
              <button onClick={() => setDeletingSalesperson(null)} className="flex-1 py-2 bg-slate-100 rounded-xl cursor-pointer">Cancelar</button>
              <button onClick={handleConfirmDeleteSalesperson} className="flex-1 py-2 bg-rose-600 text-white rounded-xl font-semibold cursor-pointer">Eliminar</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Registrar Informe */}
      {isNewReportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm mx-auto rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-xs">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">Registrar Informe de Ventas</h3>
              <button onClick={() => setIsNewReportModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveReport} className="p-4 overflow-y-auto space-y-3.5 flex-1">
              {repError && <div className="p-2 bg-rose-50 text-rose-700 rounded-lg text-[11px]">{repError}</div>}

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Vendedora *</label>
                <select
                  required
                  value={repSalespersonId}
                  onChange={(e) => setRepSalespersonId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                >
                  {salespersons.map((s) => (
                    <option key={s.id} value={s.id}>{s.name} (@{s.username})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Fecha de la venta *</label>
                <input
                  type="date"
                  required
                  value={repDate}
                  onChange={(e) => setRepDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="space-y-2 pt-1 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-slate-800 uppercase">Productos vendidos:</label>
                  <button
                    type="button"
                    onClick={handleAddReportItemRow}
                    className="text-blue-600 hover:text-blue-800 font-semibold text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Agregar fila</span>
                  </button>
                </div>

                {products.length === 0 ? (
                  <p className="text-xs text-rose-600 italic">Registra productos en el almacén primero.</p>
                ) : (
                  <div className="space-y-2">
                    {repItems.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200">
                        <div className="flex-1">
                          <select
                            value={item.productId}
                            onChange={(e) => {
                              const newId = e.target.value;
                              setRepItems((prev) => prev.map((it, i) => (i === idx ? { ...it, productId: newId } : it)));
                            }}
                            className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs text-slate-800"
                          >
                            {products.map((p) => (
                              <option key={p.id} value={p.id}>{p.name} (${p.sellPrice.toFixed(2)})</option>
                            ))}
                          </select>
                        </div>
                        <div className="w-20">
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => {
                              const val = parseInt(e.target.value, 10) || 1;
                              setRepItems((prev) => prev.map((it, i) => (i === idx ? { ...it, quantity: val } : it)));
                            }}
                            className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs text-center font-bold"
                            placeholder="Cant"
                          />
                        </div>
                        <button type="button" onClick={() => handleRemoveReportItemRow(idx)} className="p-1.5 text-slate-400 hover:text-rose-600">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button type="button" onClick={() => setIsNewReportModalOpen(false)} className="px-3 py-2 bg-slate-100 rounded-xl cursor-pointer">Cancelar</button>
                <button type="submit" disabled={products.length === 0} className="px-4 py-2 bg-blue-600 text-white rounded-xl font-semibold cursor-pointer">Registrar Informe</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL COPIA DE SEGURIDAD */}
      {isBackupModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 text-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Copia de Seguridad</h3>
                  <p className="text-[11px] text-slate-500">Respalda o restaura tus datos</p>
                </div>
              </div>
              <button
                onClick={() => setIsBackupModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 my-3">
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-2 text-slate-800 font-bold mb-1">
                  <FileDown className="w-4 h-4 text-blue-600" />
                  <span>1. Descargar Respaldo</span>
                </div>
                <p className="text-[11px] text-slate-500 mb-2.5 leading-relaxed">
                  Guarda un archivo <strong>.JSON</strong> en tu teléfono con todos los productos, categorías, vendedoras, ventas e historial.
                </p>
                <button
                  onClick={handleExportBackup}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-xs transition-colors active:scale-95 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar Copia (.JSON)</span>
                </button>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-2 text-slate-800 font-bold mb-1">
                  <FileUp className="w-4 h-4 text-emerald-600" />
                  <span>2. Restaurar Respaldo</span>
                </div>
                <p className="text-[11px] text-slate-500 mb-2.5 leading-relaxed">
                  Carga un archivo <strong>.JSON</strong> previamente guardado para recuperar inmediatamente todos tus datos.
                </p>
                <label className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold text-xs transition-colors active:scale-95 cursor-pointer shadow-xs">
                  <FileUp className="w-3.5 h-3.5" />
                  <span>Cargar Archivo .JSON</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportBackup}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => setIsBackupModalOpen(false)}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium cursor-pointer text-xs"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
